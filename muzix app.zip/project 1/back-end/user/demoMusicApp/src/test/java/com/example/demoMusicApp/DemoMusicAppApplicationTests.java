package com.example.demoMusicApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMusicAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
