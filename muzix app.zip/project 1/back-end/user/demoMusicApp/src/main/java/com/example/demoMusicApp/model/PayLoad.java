package com.example.demoMusicApp.model;

public class PayLoad {
	String token;
	UserRegistration user;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public UserRegistration getUser() {
		return user;
	}

	public void setUser(UserRegistration user) {
		this.user = user;
	}

}
