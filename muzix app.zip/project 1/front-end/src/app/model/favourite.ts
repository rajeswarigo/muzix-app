export class Favourite{
    
    name:string;
    url:string;
    artist: string;

    constructor(name:string,url:string,artist:string){
        this.name=name;
        this.url=url;
        this.artist=artist;
    }
}