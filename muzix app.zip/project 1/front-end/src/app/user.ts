export class User {
    id: number | undefined ;
    username:string | undefined ;
    emailid:string | undefined;
    password:string | undefined;

    constructor(){}



}
